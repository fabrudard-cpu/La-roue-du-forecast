# La roue du forecast — projet Android

Application Android personnelle avec une interface HTML locale embarquée dans une WebView.

## Obtenir l'APK sans installer Android Studio (compilation cloud)

1. Créer un compte gratuit sur https://github.com si nécessaire.
2. Créer un nouveau dépôt GitHub, par exemple `la-roue-du-forecast`.
3. Décompresser cette archive ZIP sur un ordinateur.
4. Dans le dépôt GitHub, choisir **Add file > Upload files**, puis déposer tout le contenu du dossier (y compris le dossier caché `.github`). Valider avec **Commit changes**.
5. Ouvrir l'onglet **Actions** du dépôt. Le workflow **Build APK** se lance automatiquement après l'envoi.
6. Quand l'exécution est terminée (pastille verte), ouvrir l'exécution et télécharger l'artefact **La-Roue-du-Forecast-APK**. L'archive contient `app-debug.apk`.
7. Transférer `app-debug.apk` sur le téléphone Android et l'ouvrir. Android peut demander d'autoriser l'installation depuis cette source.

Le workflow `.github/workflows/build-apk.yml` compile automatiquement l'APK avec Java, Gradle et le SDK Android dans les serveurs GitHub. Aucun Android Studio n'est nécessaire sur ton ordinateur.

## Fonctionnalités
- 8 secteurs : 10 000 €, 30 000 €, 100 000 €, 0 €, JOKER, 50 000 €, REJOUER, 50 €.
- Rotation animée et tirage aléatoire.
- JOKER et REJOUER accordent un nouveau tour.
- Résultat mis en évidence et historique de la session.

## Logo Carrier
Le visuel « Carrier » dans l'interface est un repère typographique provisoire, pas le fichier officiel de la marque. Le portail Carrier Brand Assets propose les déclinaisons françaises : https://adkit.carrier.com/en/us/logos/carrier-french-for-the-world-we-share
Remplacer le bloc `.logo` dans `app/src/main/assets/index.html` par le fichier graphique autorisé fourni par Carrier si tu disposes des droits d'utilisation.

Application personnelle non officielle, sans affiliation ni approbation de Carrier.
